---
title: Node Types
description: Introduction to puq.ai node types.
nav_order: 5
has_children: true
has_toc: true
---

# Node Types